<!--Navigation bar start-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid ">
    <img src="pictures/logo.png" style="width:5%;height=5%"/><a class="navbar-brand" ><b>Sports Eye</b></a>


    <!--toggle button-->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="true" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse justify-content-end " id="navbarNav">


	<nav class="navbar navbar-light">
  <div class="container-fluid">
    <form class="d-flex">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
    </form>
  </div>
</nav>
	
      <ul class="navbar-nav">
        
		<li class="nav-item">
          <a class="nav-link text-dark fs-5" href="home.php"><b>Home</b></a>
        </li>
     <li class="nav-item">
          <a class="nav-link text-dark fs-5" href="signup.php"><b>SignUp</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark fs-5" href="login.php"></i><b>LogIn</b></a>
        </li>
      </ul>

    </div>
  </div>
</nav>
