<!-- Footer -->
  <footer class="text-center text-white" style="background-color: #000000">
   
    <div class="container">
	
      
      <section class="mb-2">
        <div class="row d-flex justify-content-center">
          <div class="col-lg-5">
		  <h2>Sports Eye</h3>
            <p>
              The best sports items suppliers in Sri lanka
            </p>
          </div>
        </div>
      </section>
     
	  <hr />

     
      <section>
       
        <div class="row text-center d-flex justify-content-center pt-1">
          
          <div class="col-md-2">
            <h6 class="text-uppercase font-weight-bold">
              <a href="about.php" class="text-white">About us</a>
            </h6>
          </div>
          
          <div class="col-md-2">
            <h6 class="text-uppercase font-weight-bold">
              <a href="categories.php" class="text-white">Our Products</a>
            </h6>
          </div>
         
          <div class="col-md-2">
            <h6 class="text-uppercase font-weight-bold">
              <a href="FAQ.php" class="text-white">FAQs</a>
            </h6>
          </div>
         
        </div>
       
      </section>

    </div>
   
    <div
         class="text-center p-1"
         style="background-color: rgba(0, 0, 0, 0.2)"
         >
      © 2021 Copyright: Sports Eye
        
    </div>
  </footer>
  <!-- Footer -->