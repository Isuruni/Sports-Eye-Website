<!--Navigation bar start-->
<div id="nav">

<nav class="navbar navbar-expand-lg navbar-light">
  <div class="container">
  
  
    <a class="navbar-brand" ><b><i>Sports Eye</i></b></a>


 
    <div class="justify-content-end " id="navbarNav">

      <ul class="navbar-nav mr-auto">
        
     <li class="nav-item">
          <a class="nav-link text-dark fs-5" href="signup.php"><b>SignUp</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark fs-5" href="login.php"><b>LogIn</b></a>
        </li>
      </ul>

    </div>
  </div>
</nav>

</div>